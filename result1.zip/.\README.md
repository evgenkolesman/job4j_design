# job4j_design
Сборка проекта  при применении различных инструментов Maven, Travis и др

[![Build Status](https://travis-ci.org/evgenkolesman/job4j_design.svg?branch=master)](https://travis-ci.org/evgenkolesman/job4j_design)


[![codecov](https://codecov.io/gh/evgenkolesman/job4j_design/branch/master/graph/badge.svg?token=QZ7M0HM4L6)](https://codecov.io/gh/evgenkolesman/job4j_design)